window.onload = function () {
	var submit = document.getElementById('submit');
	submit.onclick = function () {
		for (var count = 1; count < document.getElementsByTagName('input').length-2; count++) {
			if (document.getElementsByTagName('input')[count].value == '') {
				alert(document.getElementsByClassName('th_nm')[--count].textContent+'를(을) 입력해주세요');
				document.getElementsByTagName('input')[++count].focus();
				return false;
			}
		}
	}
}